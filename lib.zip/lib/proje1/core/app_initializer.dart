import 'package:flutter_application_1/proje1/core/services_locator/services_locator.dart';

class AppInitializer {
  static void get servicesLocatorInit => ServicesLocator.init;
}
